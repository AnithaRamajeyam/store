export interface list { 
    id: number;
    name: string;
 }