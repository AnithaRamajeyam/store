export class Accessory{
    accessaryName:String;
}