export class Accessory{
    accessoryId:number;
    accessoryName:String;
}