import { Component, OnInit } from '@angular/core';
import { FormBuilder,FormControl, FormGroup,FormArray, Validators } from '@angular/forms';
import { SaveOrderService } from '../service/save-order.service';

@Component({
  selector: 'app-save-order',
  templateUrl: './save-order.component.html',
  styleUrls: ['./save-order.component.css']
})
export class SaveOrderComponent implements OnInit {

  seriesList: any[];
  modelList: any[];
  seriesid: number;
  modelid: number;
  size: number;
  accessoryList: any[];
  colorList: any[];
 
  constructor(private formBuilder: FormBuilder,private saveOrderService: SaveOrderService,) { 
  }
  saveOrderForm = new FormGroup({
    seriesname: new FormControl('', Validators.required),
    modelname: new FormControl('', Validators.required),
    accessoryname: new FormArray([]),
    colorname: new FormControl('', Validators.required),
    quantity: new FormControl('', Validators.required)
  });


  ngOnInit() {

    this.saveOrderService.getSeries().subscribe((data: any[]) => {
      console.log(data)
      this.seriesList = data;
    }, (error: any) => console.error('Error Occured', error))
  }

  changeSeries(event: any) {

    console.log(event.target.value);

    for (let series of this.seriesList) {
      if (series.seriesName == event.target.value) {
        this.seriesid = series.seriesId;
        console.log(this.seriesid);
      }
    }
    this.saveOrderService.getModel(this.seriesid).subscribe((data: any[]) => {

      if (data != null) {
        this.modelList = data;
      }
      else {
        console.log("empty object");
      }
    }, (error: any) => console.error('Error Occured while retrieving Model', error))
  }
  changeModels(event: any) {
    console.log(event.target.value)
    for (let model of this.modelList) {
      if (model.modelName == event.target.value) {
        this.modelid = model.modelId;
        console.log(this.modelid);
      }
    }
    this.saveOrderService.getAccessory(this.modelid).subscribe((data: any[]) => {
      console.log(data)
      this.accessoryList = data;
    }, (error: any) => console.error('Error Occured while retrieving accessory', error));

    this.saveOrderService.getColor(this.modelid).subscribe((data: any[]) => {
      console.log(data)
      this.colorList = data;
    }, (error: any) => console.error('Error Occured while retrieving accessory', error))

  }
  onCheckboxChange(e: { target: { checked: any; value: any; }; }) {
    if (e.target.checked) {
      console.log(e.target.value);
    }
  }
  onSubmit(){
    console.log(this.saveOrderForm.value.seriesname);
    console.log(this.saveOrderForm.value.modelname);
    console.log(this.saveOrderForm.value.accessoryname);
    console.log(this.saveOrderForm.value.colorname);
  }
}
