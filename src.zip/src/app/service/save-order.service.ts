import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {Observable} from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class SaveOrderService {

  constructor(private httpClient: HttpClient) { }

  public getSeries() : Observable<any>
  {
    return this.httpClient.get("http://localhost:9090/seriesmodel/series");
  }

  public getModel(id) : Observable<any>
  {
    const serviceURL = "http://localhost:9090/seriesmodel/model" + '/' + id;
 
        return this.httpClient.get<any>(serviceURL);
  }
  public getAccessory(id): Observable<any>
  {
    const serviceURL = "http://localhost:7070/accessory" + '/' + id;
 
        return this.httpClient.get<any>(serviceURL);
  }
  public getColor(id): Observable<any>
  {
    const serviceURL = "http://localhost:7090/color" + '/' + id;
 
        return this.httpClient.get<any>(serviceURL);
  }
  
}
