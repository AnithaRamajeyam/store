import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class SaveOrderService {

  constructor(private httpClient: HttpClient) { }

  public getSeries()
  {
    return this.httpClient.get("http://localhost:9090/seriesmodel/series");
  }

  public getModel(id)
  {
    const serviceURL = "http://localhost:9090/seriesmodel/model" + '/' + id;
 
        return this.httpClient.get<any>(serviceURL);
  }
  public getAccessory(id)
  {
    const serviceURL = "http://localhost:7070/accessory" + '/' + id;
 
        return this.httpClient.get<any>(serviceURL);
  }
  public getColor(id)
  {
    const serviceURL = "http://localhost:7090/color" + '/' + id;
 
        return this.httpClient.get<any>(serviceURL);
  }
}
